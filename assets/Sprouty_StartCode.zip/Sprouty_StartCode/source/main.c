#include "project.h"
#include "OnethinxCore01.h"
#include "OnethinxExt01.h"
#include "LoRaWAN_keys.h"
#include <cyfitter_cfg.h>
#include "sprouty.h"

coreConfiguration_t	coreConfig = {								
	.Join.KeysPtr = 			&TTN_OTAAkeys,					
	.Join.DataRate =			DR_AUTO,						
	.Join.Power =				PWR_MAX,						
	.Join.MAXTries = 			5,								
	.Join.SubBand_1st =     	EU_SUB_BANDS_DEFAULT,			
	.Join.SubBand_2nd =     	EU_SUB_BANDS_DEFAULT,			
	.TX.Confirmed = 			false,							
	.TX.DataRate = 				DR_ADR,							
	.TX.Power = 				PWR_ADR,						
	.TX.FPort = 				1,								
	.RX.Boost = 				true,							
	.System.Idle.Mode = 		M0_DeepSleep,					
	.System.Idle.BleEcoON =		false,							
	.System.Idle.DebugON =		true							
};

sleepConfig_t sleepConfig=										
{
	.sleepMode = modeDeepSleep,									
	.BleEcoON = false,											
	.DebugON = true,											
	.sleepCores = coresBoth,									
	.wakeUpPin = wakeUpPinHigh(true),							
	.wakeUpTime = wakeUpDelay(0, 0, 1, 0) 						
};

int main(void)
 {
	CyDelay(2000);
	__enable_irq();

	for(;;)
	{

	}
}

/* [] END OF FILE */
