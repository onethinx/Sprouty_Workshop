/*******************************************************************************
* File Name: LPComp.c
* Version 1.10
*
* Description:
*  This file provides the source code to the API for the Low Power Comparator
*  component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "LPComp.h"

/** LPComp_initVar indicates whether the LPComp  component
*  has been initialized. The variable is initialized to 0 and set to 1 the first
*  time LPComp_Start() is called.
*  This allows the component to restart without reinitialization after the first 
*  call to the LPComp_Start() routine.
*
*  If re-initialization of the component is required, then the 
*  LPComp_Init() function can be called before the 
*  LPComp_Start() or LPComp_Enable() function.
*/
uint8_t LPComp_initVar = LPComp_NOT_INITIALIZED;

/** The instance-specific configuration structure. This should be used in the 
*  associated LPComp_Init() function.
*/
const cy_stc_lpcomp_config_t LPComp_config =
{
    (cy_en_lpcomp_out_t)LPComp_OUT_MODE,
    (cy_en_lpcomp_hyst_t)LPComp_HYSTERESIS,
    (cy_en_lpcomp_pwr_t)LPComp_POWER,
    (cy_en_lpcomp_int_t)LPComp_INTERRUPT
};

/*******************************************************************************
* Function Name: LPComp_Start
****************************************************************************//**
*
* Summary:
*  Performs all of the required initialization for the component and enables
*  power to the block. The first time the routine is executed, the component is
*  initialized to the configuration from the customizer. When called to restart
*  the comparator following a LPComp_Stop() call, the current
*  component parameter settings are retained.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  LPComp_initVar: Is modified when this function is called for the
*   first time. Is used to ensure that initialization happens only once.
*
*******************************************************************************/
void LPComp_Start(void)
{
    if (LPComp_NOT_INITIALIZED == LPComp_initVar)
    {
        LPComp_Init();
        LPComp_initVar = LPComp_INITIALIZED;
    }
    LPComp_Enable();
}


/*******************************************************************************
* Function Name: LPComp_Init
****************************************************************************//**
*
* Summary:
*  Initializes or restores the component according to the customizer settings.
*  It is not necessary to call LPComp_Init() because the
*  LPComp_Start() API calls this function and is the preferred method
*  to begin component operation.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void LPComp_Init(void)
{
    uint32_t interruptMask;
    
    (void)Cy_LPComp_Init(LPComp_HW, LPComp_CHANNEL, &LPComp_config);

    interruptMask = LPComp_GetInterruptMask();
    LPComp_SetInterruptMask(interruptMask | LPComp_INTR_MASK);
    
    #if (0u != LPComp_LOCAL_VREF_INPUT)
        Cy_LPComp_ConnectULPReference(LPComp_HW, LPComp_CHANNEL);
        Cy_LPComp_UlpReferenceEnable(LPComp_HW);
    #endif 
}


/* [] END OF FILE */
